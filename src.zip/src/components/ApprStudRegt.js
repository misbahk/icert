import React, { Component } from 'react'

export class ApprStudRegt extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default ApprStudRegt
