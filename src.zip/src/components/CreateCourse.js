import React, { Component } from 'react'
import { Card, Table, Modal, Form, Row, Col, InputGroup, FormControl} from 'react-bootstrap';


class CreateCourse extends Component {
    state = {
      launchyes:false,
        show:false
    }

    setShow = () =>{
        this.setState({
          
            show:true
        })
    }

    setLaunch = () =>{
      this.setState({
       
          launchyes:true,
        
      })
  }


  hidelaunch = () =>{
    this.setState({
     
        launchyes:false
    })
}


    hideFn = () =>{
        this.setState({
    
            show:false
        })
    }
    render() {
        return (
           <>
             <Card size="lg" className="mobcard p-3"  >

<Card.Body>  

<button onClick={this.setShow}
 style={{width:"8rem", height:"2.5rem", backgroundColor:"rgb(61, 73,192)",marginBottom:"1rem",
     borderWidth:"thin", borderRadius:"1.5rem",  color:"white"}}>Create Course</button>


<br/>


<Table responsive>
  <thead>
    <tr>
      <th >S.no </th>
     
      <th >Course Name </th>
     <th >Class No</th>
      <th >Batch. No</th>
     <th style={{ textAlign:"center"}}>Action</th>
     <th >Pending Approval</th>
   <button style={{border:"0px", borderRadius:"1.5rem",color:"#fff",height:"2rem",
backgroundColor:"#0f6797", fontSize:"0.8rem"
}} >  <th  onClick={this.setLaunch} style={{border:"0"}} >Issue Certificate    </th></button> 
    </tr>
    <br/>

  </thead>



  <tbody>
    <tr>
      <td>1</td>
      <td style={{color:"grey"}}>Marble Cake</td>
      <td style={{color:"grey"}}>wedding Cake</td>
      <td style={{color:"grey"}}>wedding </td>
      <td><button style={{border:"0px", backgroundColor:"transparent", width:"31%"}}>Add</button>
      <button style={{border:"0px", backgroundColor:"transparent", width:"30%"}}>Edit</button>
      <button style={{border:"0px", backgroundColor:"transparent", width:"37%"}}>View</button>
      </td>

      <td style={{color:"grey"}}>Marble Cake</td>

      <td style={{color:"grey"}}>    <button onClick={this.setLaunch}
style={{border:"0px", borderRadius:"1.5rem",color:"#fff",height:"2rem",
backgroundColor:"#0f6797", fontSize:"0.8rem"
}}> Issue Certificate</button> </td>

    </tr>
    <br/>

    <tr>
      <td>2</td>
      <td style={{color:"grey"}}>Marble Cake</td>
      <td style={{color:"grey"}}>wedding Cake</td>
      <td style={{color:"grey"}}>wedding </td>
      <td><button style={{border:"0px", backgroundColor:"transparent",  width:"31%"}}>Add</button>
      <button style={{border:"0px", backgroundColor:"transparent", width:"30%"}}>Edit</button>
      <button style={{border:"0px", backgroundColor:"transparent", width:"37%"}}>View</button>
      </td>
      <td style={{color:"grey"}}>wedding Cake</td>
      <td style={{color:"grey"}}>
      
      <button onClick={this.setLaunch}
style={{border:"0px", borderRadius:"1.5rem",color:"#fff",height:"2rem",
backgroundColor:"#0f6797", fontSize:"0.8rem"
}}> Issue Certificate</button>
       </td>
      
    </tr>



    <br/>
    <tr>
      <td>3</td>
      <td style={{color:"grey"}}>Marble Cake</td>
      <td style={{color:"grey"}}>wedding Cake</td>
      <td style={{color:"grey"}}>wedding </td>
      <td><button style={{border:"0px", backgroundColor:"transparent",  width:"31%"}}>Add</button>
      <button style={{border:"0px", backgroundColor:"transparent", width:"30%"}}>Edit</button>
      <button style={{border:"0px", backgroundColor:"transparent", width:"37%"}}>View</button>
      </td>
      <td style={{color:"grey"}}>wedding Cake</td>
      <td style={{color:"grey"}}><button onClick={this.setLaunch}
style={{border:"0px", borderRadius:"1.5rem",color:"#fff",height:"2rem",
backgroundColor:"#0f6797", fontSize:"0.8rem"
}}> Issue Certificate</button> </td>
    </tr>
  </tbody>
</Table>

</Card.Body>
</Card>


  

           

<Modal 
        show={this.state.show}
        onHide={this.hideFn}
        dialogClassName="modal-20w "
        aria-labelledby="example-custom-modal-styling-title"
      >
    

        <Modal.Title id="example-custom-modal-styling-title"style={{color:"#32062c",marginTop:"2rem"}}>
          Create Course
          </Modal.Title>
        
       
        <Modal.Body style={{marginLeft:"0px"}}>
      
<br/>

<label> Course Name   </label> 
<br/>
<input style={{width:"100%", height:"6vh"}}placeholder="Course Name"></input>
<br/>
<label> Class Number   </label><br/>
<input  style={{width:"100%", height:"6vh"}} placeholder="Class Number"></input>
<br/>
<label>  batch Number  </label><br/>
<input  style={{width:"100%", height:"6vh"}} placeholder="Batch Number"></input>
<br/>

<Form style={{width:"100%", height:"6vh"}}>
  <Form.Group controlId="exampleForm.SelectCustom">
    <Form.Label>Select a Certificate</Form.Label>
    <Form.Control as="select" custom>
    <option>Select..</option>
      <option>NIIT-ECE</option>
      <option>MBA-Finance</option>
      <option>GSSS-Ruby on Rails</option>
      <option>SJCE- React JS</option>

    </Form.Control>
  </Form.Group>
</Form>
<br/>

<br/>
<button   style={{border:"0px", borderRadius:"1.5rem",color:"#fff",height:"2rem",
backgroundColor:"rgb(19, 130, 23)", fontSize:"0.8rem"
}}>Create Course</button>
<button show={this.state.show}
        onClick={this.hideFn}
style={{border:"0px", borderRadius:"1.5rem",color:"#fff", width:"4rem",height:"2rem",
backgroundColor:"rgb(202, 69, 69)", fontSize:"0.8rem", marginLeft:"3px"
}}
>Cancel</button>
        </Modal.Body>
      </Modal>






      <Modal 
        show={this.state.launchyes}
        onHide={this.hidelaunch}
        dialogClassName="modal-20w "
        aria-labelledby="example-custom-modal-styling-title"
      >
    

        <Modal.Title id="example-custom-modal-styling-title"
        style={{color:"#32062c",marginTop:"2rem", marginBottom:"-1rem"}}>
      Pending Approval

          </Modal.Title>

    <br/>
  
    <nav class="navbar navbar-light bg-light">
  <form class="form-inline">
    <input class="form-control mr-sm-2" type="search" placeholder="Search Student Name" aria-label="Search"/>
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
  </form>
</nav>


<Form>
  <Row>

  <div class="form-group" >
    <div class="form-check" style={{marginTop:"3px", marginLeft:"2rem"}} >
      <input  style={{marginTop:"8px"}}  class="form-check-input" type="checkbox" id="gridCheck"/>
      <label class="form-check-label" for="gridCheck">
       Select all
      </label>
    </div>
  </div>
    <Col>


    <button   
onClick={this.hidelaunch}

style={{border:"0px", borderRadius:"1.5rem",color:"#fff",height:"2rem",width:"7rem",
backgroundColor:"rgb(19, 130, 23)", fontSize:"0.8rem"
}}>Issue Certificate</button>     
    </Col>
    <Col>
 
    </Col>
 
  </Row>
</Form>
       
        <Modal.Body style={{marginLeft:"0px"}}>
      
<br/>

<ol>
<li>
<Form>
  <Row>
    
  <input style={{marginTop:"13px"}} class="form-check-input" type="checkbox" id="gridCheck"/>

    <Col> 
      <Form.Control placeholder="First name" />
    </Col>
    <Col>
      <Form.Control placeholder="Last name" />
    </Col>
 
  </Row>
</Form>

</li>

<br/>

<li>
<Form>
  <Row>
  <input style={{marginTop:"13px"}} class="form-check-input" type="checkbox" id="gridCheck"/>

    <Col>
      <Form.Control placeholder="First name" />
    </Col>
    <Col>
      <Form.Control placeholder="Last name" />
    </Col>
 
  </Row>
</Form>

</li>
<br/>

<li>
<Form>
  <Row>
  <input style={{marginTop:"13px"}} class="form-check-input" type="checkbox" id="gridCheck"/>

    <Col>
      <Form.Control placeholder="First name" />
    </Col>
    <Col>
      <Form.Control placeholder="Last name" />
    </Col>
 
  </Row>
</Form>

</li>

</ol>

<br/>





<br/><br/>

        </Modal.Body>
      </Modal>





</>

        )
    }
}

export default CreateCourse
